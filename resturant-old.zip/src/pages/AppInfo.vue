<template>
  <div class="q-pa-md">

    <transition appear enter-active-class="animated slower fadeInLeft" leave-active-class="animated fadeInLeft">
      <p class="text-weight-bold text-h6  q-px-md "> App Name :</p>
    </transition>

    <transition appear enter-active-class="animated slower fadeInRight" leave-active-class="fadeInRight">

      <p class="text-weight-bold  q-pa-md text-grey bg-white">Hungry Food App</p>
    </transition>

    <transition appear enter-active-class="animated slower fadeInLeft" leave-active-class="animated fadeInLeft">
      <p class="text-weight-bold text-h6  q-px-md ">Version :</p>
    </transition>

    <transition appear enter-active-class="animated slower fadeInRight" leave-active-class="fadeInRight">
      <p class="text-weight-bold text-grey bg-white  q-pa-md">Hungry 1.O</p>
    </transition>

    <transition appear enter-active-class="animated slower fadeInLeft" leave-active-class="animated fadeInLeft">
      <p class="text-weight-bold text-h6  q-px-md ">Developer :</p>
    </transition>

    <transition appear enter-active-class="animated slower fadeInRight" leave-active-class="fadeInRight">
      <p class="text-weight-bold text-grey bg-white  q-pa-md">Akshay Dhivare</p>
    </transition>




    <transition appear enter-active-class="animated slower fadeInLeft" leave-active-class="animated fadeInLeft">
      <p class="text-weight-bold text-h6  q-px-md ">Description :</p>
    </transition>

    <transition appear enter-active-class="animated slower fadeInRight" leave-active-class="fadeInRight">
      <p class="text-weight-bold text-grey bg-white  q-pa-md">Lorem, ipsum dolor sit amet consectetur adipisicing elit.
        Illo,
        similique?
      </p>
    </transition>

  </div>
</template>

<script>
export default {

}
</script>

<style scoped></style>
